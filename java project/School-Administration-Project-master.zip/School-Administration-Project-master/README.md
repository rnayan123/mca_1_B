# School-Administration-Project

Details of any student or teacher can be handled (enter the details of new admissions, update/delete
entries) by an authorized Administrator of the School. Also, fee structure of all quarters for all classes
can be maintained by him/her. 

### Prerequisites

[jdk 8](https://www.oracle.com/java/technologies/javase-jdk8-downloads.html) (or above)
