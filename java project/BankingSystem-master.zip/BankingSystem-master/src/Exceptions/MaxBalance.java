package Exceptions;

public class MaxBalance extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MaxBalance(String s)
	{
		super(s);
	}

}
