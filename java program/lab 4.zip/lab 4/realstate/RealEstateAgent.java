package realstate;

public interface RealEstateAgent {
    void promoteListing(RealEstateListing listing);

    void sellProperty(RealEstateListing listing);
}
