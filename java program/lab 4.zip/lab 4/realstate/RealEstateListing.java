package realstate;
public interface RealEstateListing {
    void displayDetails();
    double calculatePrice();
}

