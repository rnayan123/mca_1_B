# WSD_PROJECT-CHATZ

Step 1: npm i
Step 2: cd frontend
        npm i
Step 3: npm start (both root folder, and frontend)

.env file content:

NODE_ENV = development
PORT = 5000
MONGO_URI = 
JWT_SECRET = thisisasecretkey
