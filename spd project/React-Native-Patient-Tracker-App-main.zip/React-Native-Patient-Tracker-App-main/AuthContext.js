import { createContext } from "react";

let AuthContext = createContext(null);

export default AuthContext;